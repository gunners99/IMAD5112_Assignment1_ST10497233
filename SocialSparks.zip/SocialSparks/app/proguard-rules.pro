# Add project specific ProGuard rules here.
# By default, the flags in this file are appended to flags specified
# in the Android SDK tools/proguard/proguard-android.txt file.

# Keep the entry point
-keep public class com.kora.socialsparks.MainActivity
